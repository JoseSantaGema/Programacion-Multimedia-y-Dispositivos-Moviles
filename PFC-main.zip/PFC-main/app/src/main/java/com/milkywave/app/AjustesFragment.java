package com.milkywave.app;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class AjustesFragment extends Fragment {

    // Campos de texto del perfil (nombre y apellidos) que el usuario puede editar
    private TextInputEditText editNombre, editApellido1, editApellido2;

    // Botones de acciones:
    // - Guardar perfil -> actualiza Firestore
    // - Cambiar contraseña -> envía email de reset de Firebase
    // - Eliminar cuenta -> reautenticación + borrar doc + borrar usuario
    // - Reenviar verificación -> envía email de verificación
    private MaterialButton btnGuardarPerfil, btnCambiarContrasena, btnEliminarCuenta, btnReenviarVerificacion;

    // FirebaseAuth: gestiona el usuario autenticado (sesión, email, borrado de cuenta, etc.)
    private FirebaseAuth auth;

    // Firestore: base de datos donde guardas el documento "usuarios/{uid}" con el perfil
    private FirebaseFirestore db;

    public AjustesFragment() {} // Constructor vacío requerido para Fragment

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        // Inflamos el layout XML del fragment (UI)
        View view = inflater.inflate(R.layout.fragment_ajustes, container, false);

        // Inicializamos instancias de Firebase (singleton)
        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // Enlazamos campos del XML con variables Java (findViewById sobre "view" porque estamos en un Fragment)
        editNombre = view.findViewById(R.id.editNombre);
        editApellido1 = view.findViewById(R.id.editApellido1);
        editApellido2 = view.findViewById(R.id.editApellido2);

        // Enlazamos botones del XML
        btnGuardarPerfil = view.findViewById(R.id.btnGuardarPerfil);
        btnCambiarContrasena = view.findViewById(R.id.btnCambiarContrasena);
        btnEliminarCuenta = view.findViewById(R.id.btnEliminarCuenta);
        btnReenviarVerificacion = view.findViewById(R.id.btnReenviarVerificacion);

        // Cargamos datos del perfil del usuario desde Firestore y los mostramos en pantalla
        cargarPerfil();

        // Listeners de clicks: cada botón llama a su método correspondiente
        btnGuardarPerfil.setOnClickListener(v -> guardarPerfil());
        btnCambiarContrasena.setOnClickListener(v -> enviarResetPassword());
        btnReenviarVerificacion.setOnClickListener(v -> reenviarVerificacion());
        btnEliminarCuenta.setOnClickListener(v -> confirmarEliminarCuenta());

        // Devolvemos la vista raíz del fragment para que se pinte
        return view;
    }

    /**
     * Lee el documento del usuario desde Firestore:
     * colección "usuarios" -> documento con ID = uid del usuario autenticado.
     * Si existe, rellena los TextInputEditText con los valores guardados.
     */
    private void cargarPerfil() {
        // Obtenemos usuario autenticado actual
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) return; // Si no hay sesión, no hay nada que cargar

        db.collection("usuarios").document(user.getUid())
                .get()
                .addOnSuccessListener(doc -> {
                    // Si el documento no existe, salimos sin hacer nada
                    if (!doc.exists()) return;

                    // Rellenamos los campos con los datos del documento
                    editNombre.setText(doc.getString("nombre"));
                    editApellido1.setText(doc.getString("apellido1"));
                    editApellido2.setText(doc.getString("apellido2"));
                })
                .addOnFailureListener(e -> toast("No se pudo cargar el perfil"));
    }

    /**
     * Guarda los cambios del perfil en Firestore.
     * - Valida que nombre y apellido1 no estén vacíos.
     * - Actualiza el documento "usuarios/{uid}" con update().
     */
    private void guardarPerfil() {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) return; // Sin usuario, no se puede guardar

        // safe(...) saca el texto y hace trim para evitar espacios extra
        String nombre = safe(editNombre);
        String ap1 = safe(editApellido1);
        String ap2 = safe(editApellido2);

        // Validación básica: nombre y primer apellido son obligatorios
        if (TextUtils.isEmpty(nombre) || TextUtils.isEmpty(ap1)) {
            toast("Nombre y Apellido 1 son obligatorios");
            return;
        }

        // Construimos mapa con los campos a actualizar en Firestore
        Map<String, Object> update = new HashMap<>();
        update.put("nombre", nombre);
        update.put("apellido1", ap1);
        update.put("apellido2", ap2);

        // Deshabilitamos botón para evitar doble clic mientras se guarda
        btnGuardarPerfil.setEnabled(false);

        db.collection("usuarios")
                .document(user.getUid())
                .update(update) // update modifica solo esos campos, no pisa el documento entero
                .addOnSuccessListener(unused -> {
                    // Volvemos a habilitar botón y mostramos feedback
                    btnGuardarPerfil.setEnabled(true);
                    toast("Perfil actualizado");
                })
                .addOnFailureListener(e -> {
                    // Si falla, habilitamos botón y mostramos error
                    btnGuardarPerfil.setEnabled(true);
                    toast("Error al actualizar: " + e.getMessage());
                });
    }

    /**
     * Envía el email oficial de Firebase para restablecer contraseña (password reset).
     * Firebase manda un correo al email del usuario con un enlace para cambiarla.
     */
    private void enviarResetPassword() {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) return;

        // Sacamos el email del usuario autenticado
        String email = user.getEmail();
        if (email == null || email.trim().isEmpty()) {
            toast("No se pudo obtener el email");
            return;
        }

        auth.sendPasswordResetEmail(email)
                .addOnSuccessListener(unused ->
                        // Si todo ok, mostramos un diálogo informativo
                        mostrarDialogo("Email enviado", "Te hemos enviado un email para cambiar la contraseña.")
                )
                .addOnFailureListener(e ->
                        // Si falla, mostramos el error en diálogo
                        mostrarDialogo("Error", "No se pudo enviar el email: " + e.getMessage())
                );
    }

    /**
     * Reenvía el email de verificación de cuenta (Firebase Auth).
     * Útil si el usuario no encontró el correo o lo perdió.
     */
    private void reenviarVerificacion() {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) return;

        user.sendEmailVerification()
                .addOnSuccessListener(unused ->
                        mostrarDialogo("Verificación enviada", "Revisa tu correo y pulsa el enlace para verificar tu cuenta.")
                )
                .addOnFailureListener(e ->
                        mostrarDialogo("Error", "No se pudo enviar: " + e.getMessage())
                );
    }

    /**
     * Paso 1 de eliminar cuenta:
     * Muestra un diálogo de confirmación general para evitar borrados accidentales.
     * Si el usuario acepta, se pasa a pedir la contraseña (reautenticación).
     *
     * Importante: Firebase exige reautenticación reciente para acciones sensibles (como delete()).
     */
    private void confirmarEliminarCuenta() {
        new AlertDialog.Builder(requireContext())
                .setTitle("Eliminar cuenta")
                .setMessage("Esta acción es permanente. Se eliminará tu cuenta y tu perfil. ¿Continuar?")
                .setPositiveButton("Continuar", (d, w) -> pedirContrasenaParaEliminar())
                .setNegativeButton("Cancelar", null)
                .show();
    }

    /**
     * Paso 2 de eliminar cuenta:
     * Pide la contraseña en un input (TextInputEditText) para reautenticar.
     * Si el usuario la introduce, llamamos a reauthYEliminar(pass).
     */
    private void pedirContrasenaParaEliminar() {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) return;

        // Creamos un campo de texto programáticamente para meter la contraseña
        TextInputEditText input = new TextInputEditText(requireContext());
        input.setHint("Introduce tu contraseña");
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

        new AlertDialog.Builder(requireContext())
                .setTitle("Confirmar contraseña")
                .setMessage("Por seguridad, introduce tu contraseña para eliminar la cuenta.")
                .setView(input)
                .setPositiveButton("Eliminar", (d, w) -> {
                    // Leemos la contraseña escrita
                    String pass = input.getText() == null ? "" : input.getText().toString();

                    // Validamos que no esté vacía
                    if (pass.trim().isEmpty()) {
                        toast("Contraseña obligatoria");
                        return;
                    }

                    // Reautenticamos y, si va bien, seguimos con el borrado
                    reauthYEliminar(pass.trim());
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    /**
     * Reautentica al usuario con email+password (EmailAuthProvider).
     * Si la contraseña es correcta, continúa con borrarPerfilYCuenta().
     */
    private void reauthYEliminar(String password) {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) return;

        // Necesitamos el email para crear el credential
        String email = user.getEmail();
        if (email == null || email.trim().isEmpty()) {
            toast("No se pudo obtener el email");
            return;
        }

        // Deshabilitamos el botón para evitar múltiples intentos mientras se procesa
        btnEliminarCuenta.setEnabled(false);

        // Credential para reauth: email + contraseña
        AuthCredential credential = EmailAuthProvider.getCredential(email, password);

        // Reautenticación (requisito de seguridad para acciones sensibles)
        user.reauthenticate(credential)
                .addOnSuccessListener(unused -> borrarPerfilYCuenta())
                .addOnFailureListener(e -> {
                    // Si falla, normalmente es contraseña incorrecta
                    btnEliminarCuenta.setEnabled(true);
                    toast("Contraseña incorrecta");
                });
    }

    /**
     * Borrado completo (sin Cloud Functions):
     * 1) Borra el documento del perfil en Firestore: usuarios/{uid}
     *    (NOTA: aquí explícitamente NO tocas tickets u otras colecciones)
     * 2) Borra el usuario de Firebase Auth: user.delete()
     * 3) Vuelve al LoginFragment (y opcionalmente ocultar el menú)
     */
    private void borrarPerfilYCuenta() {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) {
            btnEliminarCuenta.setEnabled(true);
            return;
        }

        String uid = user.getUid();

        // 1) Borra perfil en Firestore (tickets NO se tocan)
        db.collection("usuarios").document(uid)
                .delete()
                .addOnSuccessListener(unused -> {
                    // 2) Borra usuario en Firebase Auth
                    user.delete()
                            .addOnSuccessListener(u2 -> {
                                btnEliminarCuenta.setEnabled(true);
                                toast("Cuenta eliminada");

                                // 3) Volver a login y ocultar menú
                                // Aquí intentas reutilizar métodos de MainActivity si está disponible
                                if (getActivity() instanceof MainActivity) {
                                    // Si tienes estos métodos en MainActivity, genial:
                                    // ((MainActivity) getActivity()).ocultarMenu();
                                    ((MainActivity) getActivity()).cambiarFragment(new LoginFragment());
                                } else if (getActivity() != null) {
                                    // Fallback por si no es MainActivity: hacemos la transacción manual
                                    getActivity().getSupportFragmentManager().beginTransaction()
                                            .replace(R.id.fragment_container, new LoginFragment())
                                            .commit();
                                }
                            })
                            .addOnFailureListener(e -> {
                                // Puede fallar si Firebase exige reauth reciente (aunque ya lo hiciste),
                                // o por errores de red/permisos.
                                btnEliminarCuenta.setEnabled(true);
                                toast("No se pudo eliminar la cuenta: " + e.getMessage());
                            });
                })
                .addOnFailureListener(e -> {
                    // Si no se puede borrar el doc del perfil, no seguimos con el delete del usuario
                    btnEliminarCuenta.setEnabled(true);
                    toast("No se pudo borrar el perfil: " + e.getMessage());
                });
    }

    /**
     * Muestra un AlertDialog simple (título + mensaje + botón Aceptar).
     * Lo usas para feedback "bonito" en lugar de solo Toast.
     */
    private void mostrarDialogo(String titulo, String msg) {
        new AlertDialog.Builder(requireContext())
                .setTitle(titulo)
                .setMessage(msg)
                .setPositiveButton("Aceptar", null)
                .show();
    }

    /**
     * Toast corto reutilizable.
     * requireContext() asegura que el fragment está adjunto; si no lo está, lanzaría excepción.
     */
    private void toast(String msg) {
        Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show();
    }

    /**
     * Helper para leer el texto de un TextInputEditText de forma segura:
     * - Si getText() es null -> devuelve ""
     * - Si no -> toString().trim() para quitar espacios
     */
    private String safe(TextInputEditText et) {
        return et.getText() == null ? "" : et.getText().toString().trim();
    }
}
