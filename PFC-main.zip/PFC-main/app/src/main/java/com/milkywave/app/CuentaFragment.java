package com.milkywave.app;

import android.app.AlertDialog;          // Para mostrar diálogos de confirmación (cerrar sesión)
import android.content.Intent;           // Para lanzar acciones del sistema (abrir navegador)
import android.net.Uri;                 // Para construir la URL que se abrirá en el navegador
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;           // Referencias a botones del layout (aunque el XML pueda ser MaterialButton, sigue funcionando)
import android.widget.TextView;         // Referencias a textos del layout (nombre y puntos)

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;      // Gestión de sesión (usuario actual, signOut)
import com.google.firebase.firestore.FirebaseFirestore; // Lectura de datos del usuario en Firestore

public class CuentaFragment extends Fragment {

    // TextViews donde pintamos:
    // - Nombre completo del usuario
    // - Puntos del usuario
    private TextView textNombreUsuario, textPuntosUsuario;

    // Firebase Auth: para saber si hay usuario logueado y para cerrar sesión
    private FirebaseAuth auth;

    // Firestore: para leer los datos del perfil del usuario (nombre, apellidos, puntos)
    private FirebaseFirestore db;

    public CuentaFragment() {} // Constructor vacío necesario para Fragment

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        // Inflamos la interfaz del fragment (fragment_cuenta.xml)
        View view = inflater.inflate(R.layout.fragment_cuenta, container, false);

        // Inicializamos Firebase (singletons)
        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // Enlazamos las vistas del XML con las variables
        textNombreUsuario = view.findViewById(R.id.textNombreUsuario);
        textPuntosUsuario = view.findViewById(R.id.textPuntosUsuario);

        // Enlazamos botones del XML
        Button btnPrivacidad = view.findViewById(R.id.btn_privacidad);
        Button btnCerrarSesion = view.findViewById(R.id.btn_cerrar_sesion);
        Button btnAjustes = view.findViewById(R.id.btn_ajustes);

        // Cargamos los datos del usuario (nombre, apellidos y puntos) desde Firestore
        cargarDatosUsuario();

        // Botón privacidad:
        // Abre la URL en el navegador (Intent implícito ACTION_VIEW)
        btnPrivacidad.setOnClickListener(v ->
                startActivity(new Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://milkywave.es/privacidad")
                ))
        );

        // Botón cerrar sesión:
        // Muestra un diálogo de confirmación antes de cerrar sesión
        btnCerrarSesion.setOnClickListener(v -> cerrarSesion());

        // Botón ajustes:
        // Cambia el fragment actual por AjustesFragment usando el método de MainActivity
        // (solo si realmente estamos dentro de MainActivity)
        btnAjustes.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).cambiarFragment(new AjustesFragment());
            }
        });

        // Devolvemos la vista para que el Fragment se muestre
        return view;
    }

    /**
     * Lee desde Firestore el documento del usuario y muestra:
     * - Nombre completo (nombre + apellidos)
     * - Puntos (campo "puntos")
     */
    private void cargarDatosUsuario() {

        // Si no hay usuario logueado, no hacemos nada
        if (auth.getCurrentUser() == null) return;

        // Obtenemos el UID del usuario actual (identificador único en Firebase Auth)
        String uid = auth.getCurrentUser().getUid();

        // Buscamos el documento del usuario en la colección "usuarios"
        db.collection("usuarios")
                .document(uid)
                .get()
                .addOnSuccessListener(doc -> {

                    // Leemos los campos del documento (pueden ser null si no existen)
                    String nombre = doc.getString("nombre");
                    String apellido1 = doc.getString("apellido1");
                    String apellido2 = doc.getString("apellido2");

                    // Construimos el nombre completo y lo mostramos
                    String nombreCompleto = nombre + " " + apellido1 + " " + apellido2;
                    textNombreUsuario.setText(nombreCompleto);

                    // Leemos puntos. Si no existe, ponemos 0.
                    Long puntos = doc.getLong("puntos");
                    textPuntosUsuario.setText(
                            puntos != null ? String.valueOf(puntos) : "0"
                    );
                });

        // Si falla la lectura (sin internet, permisos, etc.) simplemente no se actualizará la UI.
    }

    /**
     * Muestra un diálogo para confirmar cierre de sesión.
     * Si el usuario acepta:
     * - Cierra sesión en FirebaseAuth
     * - Oculta el menú inferior (BottomNavigation) desde MainActivity
     * - Cambia al LoginFragment
     */
    private void cerrarSesion() {

        new AlertDialog.Builder(requireContext())
                .setTitle("Cerrar sesión")
                .setMessage("¿Seguro que quieres cerrar sesión?")
                .setPositiveButton("Sí", (dialog, which) -> {

                    // Cierra sesión en Firebase
                    FirebaseAuth.getInstance().signOut();

                    // Volvemos al login y ocultamos el menú
                    if (getActivity() instanceof MainActivity) {
                        MainActivity activity = (MainActivity) getActivity();
                        activity.ocultarMenu();
                        activity.cambiarFragment(new LoginFragment());
                    }
                })
                .setNegativeButton("No", null) // Si pulsa "No", simplemente se cierra el diálogo
                .show();
    }

}
