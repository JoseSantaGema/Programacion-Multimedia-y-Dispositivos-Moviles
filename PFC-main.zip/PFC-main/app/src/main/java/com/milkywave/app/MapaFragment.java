package com.milkywave.app;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.button.MaterialButton; // Botones Material para zoom +/-

import org.osmdroid.config.Configuration;              // Configuración global de osmdroid (cache, user agent, prefs, etc.)
import org.osmdroid.events.MapListener;                // Listener para eventos del mapa (scroll/zoom)
import org.osmdroid.events.ScrollEvent;                // Evento de scroll/pan
import org.osmdroid.events.ZoomEvent;                  // Evento de zoom
import org.osmdroid.tileprovider.tilesource.TileSourceFactory; // Fuente de tiles (MAPNIK = OpenStreetMap)
import org.osmdroid.util.GeoPoint;                     // Coordenadas (lat, lon)
import org.osmdroid.views.MapView;                     // Vista del mapa
import org.osmdroid.views.overlay.Marker;              // Marcadores (pins) encima del mapa

public class MapaFragment extends Fragment {

    // Límites de zoom que quieres permitir en el mapa
    // (para que el usuario no pueda alejarse/acercarse demasiado), si lo hace termina en bug
    private static final double MIN_ZOOM = 11.0;
    private static final double MAX_ZOOM = 19.0;

    // Referencia al MapView del layout
    private MapView map;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        // 1) Cargar configuración de osmdroid
        // osmdroid recomienda cargar Configuration con un contexto y unas SharedPreferences.
        // Esto suele configurar cache, opciones de red, y evita warnings/errores.
        Configuration.getInstance().load(
                requireContext(),
                requireContext().getSharedPreferences("prefs", 0)
        );

        // 2) Inflar el layout del fragment (fragment_mapa.xml)
        View view = inflater.inflate(R.layout.fragment_mapa, container, false);

        // 3) Inicializar el mapa y ajustes básicos
        map = view.findViewById(R.id.map);

        // MAPNIK es el estilo clásico de tiles de OpenStreetMap
        map.setTileSource(TileSourceFactory.MAPNIK);

        // Permite gestos de zoom con dos dedos y desplazamiento
        map.setMultiTouchControls(true);

        // Establecemos límites de zoom (para controlar UX y evitar valores extremos)
        map.setMinZoomLevel(MIN_ZOOM);
        map.setMaxZoomLevel(MAX_ZOOM);

        // 4) Posición inicial del mapa
        // Centro en Leganés y zoom inicial 14
        GeoPoint leganes = new GeoPoint(40.3592264, -3.7773986);
        map.getController().setZoom(14.0);
        map.getController().setCenter(leganes);

        // 5) Añadir marcadores de tiendas
        // Cada marker tiene coordenadas + título
        addMarker(new GeoPoint(40.3592264, -3.7773986), "Tienda Leganés");
        addMarker(new GeoPoint(40.4717531, -3.4411947), "Tienda Torrejón de Ardoz");
        addMarker(new GeoPoint(40.6227197, -3.1655156), "Tienda Guadalajara");

        // 6) Botones de zoom (MaterialButton) desde el layout
        MaterialButton zoomIn = view.findViewById(R.id.btn_zoom_in);
        MaterialButton zoomOut = view.findViewById(R.id.btn_zoom_out);

        // Zoom + (y luego ajustamos para no pasarnos de MAX_ZOOM)
        zoomIn.setOnClickListener(v -> {
            map.getController().zoomIn();
            clampZoom();
        });

        // Zoom - (y luego ajustamos para no bajar de MIN_ZOOM)
        zoomOut.setOnClickListener(v -> {
            map.getController().zoomOut();
            clampZoom();
        });

        // 7) Listener de eventos del mapa
        // Cada vez que el usuario hace scroll o zoom (gestos), llamamos a clampZoom()
        // para asegurar que el zoom se mantenga dentro de los límites.
        map.addMapListener(new MapListener() {
            @Override
            public boolean onScroll(ScrollEvent event) {
                clampZoom();
                return true; // true indica que el evento se ha manejado
            }

            @Override
            public boolean onZoom(ZoomEvent event) {
                clampZoom();
                return true;
            }
        });

        return view;
    }

    /**
     * Asegura que el zoom actual del mapa se mantenga entre MIN_ZOOM y MAX_ZOOM.
     * Si el usuario intenta ir más allá (con gestos o botones), lo “corrige”.
     */
    private void clampZoom() {
        double z = map.getZoomLevelDouble();
        if (z < MIN_ZOOM) map.getController().setZoom(MIN_ZOOM);
        if (z > MAX_ZOOM) map.getController().setZoom(MAX_ZOOM);
    }

    /**
     * Añade un marcador al mapa:
     * - point: coordenadas del marcador
     * - title: texto que se muestra (tooltip/ventanita) cuando pulsas el marker
     */
    private void addMarker(GeoPoint point, String title) {
        Marker marker = new Marker(map);                      // El marker necesita el MapView asociado
        marker.setPosition(point);                            // Coordenadas del marker
        marker.setTitle(title);                               // Texto del marker
        marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM); // Ajusta el “anclaje” para que el pin apunte bien
        map.getOverlays().add(marker);                        // Se añade a la capa de overlays
        map.invalidate();                                     // Forzamos repaint para que se vea inmediatamente
    }

    @Override
    public void onResume() {
        super.onResume();
        // Nota, Osmdroid recomienda llamar a map.onResume() para reactivar sensores/recursos
        if (map != null) map.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        // Nota, Osmdroid recomienda llamar a map.onPause() para pausar y liberar recursos
        if (map != null) map.onPause();
    }
}
