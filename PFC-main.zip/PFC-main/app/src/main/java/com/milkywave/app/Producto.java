package com.milkywave.app;

import java.io.Serializable;      // Permite pasar este objeto entre fragments/activities (por ejemplo en un Bundle)
import java.util.ArrayList;       // Lista dinámica para guardar las opciones del producto (tamaños/sabores/variantes)

public class Producto implements Serializable {

    // Nombre del producto (ej: "Original", "Tarrina", "Milkshake", etc.)
    // final = inmutable: una vez creado el Producto, no se modifica.
    public final String nombre;

    // Descripción general del producto (texto largo que aparece en el diálogo/pantalla detalle)
    public final String descripcion;

    // ID del recurso drawable de la imagen principal del producto (R.drawable.xxx)
    // Se usa como "portada" del producto.
    public final int imagenPrincipalResId;

    // Lista de opciones asociadas a este producto.
    // Cada OpcionProducto puede representar un tamaño/sabor/variante con su precio, imagen y detalle.
    public final ArrayList<OpcionProducto> opciones;

    /**
     * Constructor:
     * Crea un Producto con todos sus datos y su lista de opciones.
     *
     * @param nombre               Nombre visible del producto
     * @param descripcion          Texto descriptivo del producto
     * @param imagenPrincipalResId Drawable de la imagen principal (portada)
     * @param opciones             Lista de opciones disponibles para este producto
     */
    public Producto(String nombre, String descripcion, int imagenPrincipalResId, ArrayList<OpcionProducto> opciones) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.imagenPrincipalResId = imagenPrincipalResId;
        this.opciones = opciones;
    }
}
