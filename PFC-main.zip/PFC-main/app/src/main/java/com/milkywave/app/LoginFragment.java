package com.milkywave.app;

import android.os.Bundle;
import android.text.InputType;     // Para cambiar el tipo de input del EditText (mostrar/ocultar contraseña)
import android.text.TextUtils;    // Utilidades para comprobar strings vacíos
import android.util.Patterns;     // Patrón oficial para validar emails
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;     // Botón de login
import android.widget.EditText;   // Campos de email y contraseña
import android.widget.ImageButton; // Botón del “ojo” para ver/ocultar contraseña
import android.widget.TextView;   // Texto para ir al registro
import android.widget.Toast;      // Mensajes rápidos por pantalla

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth; // Firebase Auth para hacer signInWithEmailAndPassword

import java.util.Locale; // Para convertir el email a minúsculas de forma consistente

public class LoginFragment extends Fragment {

    // Referencias a los campos del formulario
    private EditText editEmail, editContrasena;

    // Botón principal para iniciar sesión
    private Button btnLogin;

    // Texto clickable para ir a la pantalla de registro
    private TextView textRegistro;

    // Botón para mostrar/ocultar contraseña
    private ImageButton btnVerContrasena;

    // FirebaseAuth: gestiona autenticación y estado del usuario
    private FirebaseAuth auth;

    // Flag para saber si la contraseña está actualmente visible
    private boolean contrasenaVisible = false;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflamos el layout login.xml
        View view = inflater.inflate(R.layout.login, container, false);

        // Obtenemos la instancia de FirebaseAuth
        auth = FirebaseAuth.getInstance();

        // Enlazamos vistas del XML con las variables Java
        editEmail        = view.findViewById(R.id.editTextEmail);
        editContrasena   = view.findViewById(R.id.editTextContrasena);
        btnLogin         = view.findViewById(R.id.btnLogin);
        textRegistro     = view.findViewById(R.id.textRegistro);
        btnVerContrasena = view.findViewById(R.id.btnVerContrasena);

        // Al pulsar "Iniciar sesión" -> validamos y llamamos a Firebase
        btnLogin.setOnClickListener(v -> login());

        // Al pulsar el “ojo” -> alternamos entre mostrar y ocultar contraseña
        btnVerContrasena.setOnClickListener(v -> toggleContrasena());

        // Texto de registro -> cambia al RegistroFragment usando el método de MainActivity
        textRegistro.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).cambiarFragment(new RegistroFragment());
            }
        });

        // Devolvemos la vista ya configurada
        return view;
    }

    /**
     * 👁 Mostrar / ocultar contraseña
     *
     * Cambia el inputType del EditText de contraseña entre:
     * - visible password (se ve el texto)
     * - password (se oculta)
     *
     * También cambia el icono del ImageButton para que el usuario entienda el estado.
     */
    private void toggleContrasena() {
        // Invertimos el estado actual
        contrasenaVisible = !contrasenaVisible;

        if (contrasenaVisible) {
            // Modo "visible": se ve la contraseña
            editContrasena.setInputType(
                    InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            );
            // Cambiamos icono a “ojo abierto”
            btnVerContrasena.setImageResource(R.drawable.ic_visibility);
        } else {
            // Modo "oculta": el sistema enmascara la contraseña
            editContrasena.setInputType(
                    InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD
            );
            // Cambiamos icono a “ojo cerrado”
            btnVerContrasena.setImageResource(R.drawable.ic_visibility_off);
        }

        // Mantener cursor al final:
        // Al cambiar inputType, Android a veces mueve el cursor al inicio.
        // Esto lo corrige para que el usuario siga escribiendo normal.
        editContrasena.setSelection(editContrasena.getText().length());
    }

    /**
     * Lógica de inicio de sesión:
     * 1) Limpia errores previos
     * 2) Lee email/contraseña
     * 3) Valida:
     *    - email no vacío
     *    - formato de email válido
     *    - contraseña no vacía
     * 4) Deshabilita botón para evitar doble click
     * 5) Llama a FirebaseAuth.signInWithEmailAndPassword
     * 6) Si login ok:
     *    - recarga usuario para obtener emailVerified actualizado
     *    - muestra mensaje según verificación
     *    - navega a InicioFragment y muestra el menú inferior
     * 7) Si login falla:
     *    - re-habilita el botón
     *    - muestra mensaje de error genérico
     */
    private void login() {
        // Quitamos errores anteriores del formulario (EditText.setError)
        clearErrors();

        // Leemos el email de forma segura (trim) y lo pasamos a minúsculas para evitar problemas
        String emailRaw   = safeText(editEmail);
        String email      = emailRaw.toLowerCase(Locale.ROOT);

        // Leemos la contraseña tal cual (aquí no haces trim, lo cual está bien: la contraseña puede llevar espacios)
        String contrasena = editContrasena.getText().toString();

        // --- Validaciones ---

        // Email obligatorio
        if (TextUtils.isEmpty(email)) {
            editEmail.setError("Obligatorio");
            editEmail.requestFocus();
            toast("Introduce tu email");
            return;
        }

        // Email con formato correcto (patrón oficial de Android)
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            editEmail.setError("Email no válido");
            editEmail.requestFocus();
            toast("Email no válido");
            return;
        }

        // Contraseña obligatoria
        if (TextUtils.isEmpty(contrasena)) {
            editContrasena.setError("Obligatorio");
            editContrasena.requestFocus();
            toast("Introduce tu contraseña");
            return;
        }

        // Deshabilitamos botón mientras se hace la petición a Firebase
        btnLogin.setEnabled(false);

        // --- Firebase login ---
        auth.signInWithEmailAndPassword(email, contrasena)
                .addOnSuccessListener(result -> {
                    // Re-habilitamos botón cuando Firebase responde OK
                    btnLogin.setEnabled(true);

                    // Si result.getUser() no es null, recargamos datos para comprobar verificación actualizada
                    if (result.getUser() != null) {
                        result.getUser().reload().addOnCompleteListener(t -> {

                            // Tras reload, isEmailVerified() es más fiable
                            boolean verificada = result.getUser().isEmailVerified();

                            // Mensaje según verificación
                            if (!verificada) {
                                toast("Cuenta no verificada. Revisa tu correo para activar los puntos.");
                            } else {
                                toast("Inicio de sesión correcto");
                            }

                            // Navegación: cambiamos a InicioFragment y mostramos menú inferior
                            if (getActivity() instanceof MainActivity) {
                                ((MainActivity) getActivity()).cambiarFragment(new InicioFragment());
                                ((MainActivity) getActivity()).mostrarMenu();
                            }
                        });
                        return; // Importante: no se sigue con el "fallback" de abajo
                    }

                    // Fallback:
                    // Si por algún motivo result.getUser() viniera null (raro), igual se deja entrar
                    toast("Inicio de sesión correcto");
                    if (getActivity() instanceof MainActivity) {
                        ((MainActivity) getActivity()).cambiarFragment(new InicioFragment());
                        ((MainActivity) getActivity()).mostrarMenu();
                    }
                })

                .addOnFailureListener(e -> {
                    // Si falla el login, se re-habilita el botón y se muestra mensaje genérico
                    btnLogin.setEnabled(true);
                    toast("Email o contraseña incorrectos");
                });
    }

    /**
     * Limpia los errores visuales del formulario (los mensajes rojos de setError)
     */
    private void clearErrors() {
        editEmail.setError(null);
        editContrasena.setError(null);
    }

    /**
     * Helper para mostrar Toasts de forma rápida
     */
    private void toast(String msg) {
        Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show();
    }

    /**
     * Helper para leer texto de un EditText:
     * - Si getText() es null -> ""
     * - Si no -> texto recortado (trim) para quitar espacios al principio/fin
     */
    private String safeText(EditText et) {
        return et.getText() == null ? "" : et.getText().toString().trim();
    }
}
