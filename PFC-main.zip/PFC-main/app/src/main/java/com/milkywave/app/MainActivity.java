package com.milkywave.app;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    // Referencia al BottomNavigationView (menú inferior) definido en activity_main.xml
    // Desde aquí controlamos qué pestaña está seleccionada y qué fragmento se muestra.
    private BottomNavigationView bottomNavigation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Cargamos el layout principal de esta Activity (contiene el contenedor de fragments y el bottom nav)
        setContentView(R.layout.activity_main);

        // Enlazamos la vista del menú inferior con su ID del XML
        bottomNavigation = findViewById(R.id.bottom_navigation);

        // Comprobación de sesión:
        // - Si hay un usuario autenticado en Firebase, entramos directamente a la pantalla de inicio
        // - Si NO hay usuario, ocultamos el menú inferior y mostramos el LoginFragment
        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            irAInicio(); // Usuario logueado -> mostrar menú y fragment de inicio
        } else {
            ocultarMenu(); // Usuario NO logueado -> no queremos que navegue por la app aún
            cambiarFragment(new LoginFragment()); // Mostramos pantalla de login
        }

        // Listener que detecta qué opción del menú inferior se pulsa
        // y cambia el fragmento del contenedor en función del botón seleccionado.
        bottomNavigation.setOnItemSelectedListener(item -> {
            int id = item.getItemId(); // ID del item del menú seleccionado

            // Cada if comprueba qué pestaña se ha pulsado y carga su fragment correspondiente.
            if (id == R.id.nav_inicio) {
                cambiarFragment(new InicioFragment());
                return true; // true indica "evento consumido", el item queda seleccionado
            } else if (id == R.id.nav_carta) {
                cambiarFragment(new CartaFragment());
                return true;
            } else if (id == R.id.nav_mapa) {
                cambiarFragment(new MapaFragment());
                return true;
            } else if (id == R.id.nav_ofertas) {
                cambiarFragment(new OfertasFragment());
                return true;
            } else if (id == R.id.nav_cuenta) {
                cambiarFragment(new CuentaFragment());
                return true;
            }

            // Si el ID no coincide con ninguno de los esperados, devolvemos false
            // (en teoría no debería ocurrir si el menú está bien definido).
            return false;
        });
    }

    /**
     * Reemplaza el fragmento actual por el fragmento que se le pasa como parámetro.
     * - replace() sustituye el contenido del contenedor (R.id.fragment_container)
     * - commit() aplica la transacción
     *
     * Nota: aquí NO se usa addToBackStack(), por lo que al pulsar "atrás"
     * no volverás al fragment anterior (volverás a salir de la app o a la Activity anterior).
     */
    public void cambiarFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }

    /**
     * Método de conveniencia para ir a la pantalla de inicio:
     * - Muestra el menú inferior
     * - Marca el item "inicio" como seleccionado
     * - Carga el fragment InicioFragment
     *
     * Esto se usa cuando el usuario ya está autenticado (o tras loguearse correctamente).
     */
    public void irAInicio() {
        mostrarMenu(); // Ahora sí permitimos navegación
        bottomNavigation.setSelectedItemId(R.id.nav_inicio); // Seleccionamos visualmente "Inicio"
        cambiarFragment(new InicioFragment()); // Mostramos contenido de inicio
    }

    /**
     * Muestra el BottomNavigationView.
     * Se usa cuando ya queremos que el usuario pueda moverse por la app.
     */
    public void mostrarMenu() {
        bottomNavigation.setVisibility(View.VISIBLE);
    }

    /**
     * Oculta el BottomNavigationView.
     * Se usa por ejemplo en el login para que el usuario no navegue sin autenticar.
     */
    public void ocultarMenu() {
        bottomNavigation.setVisibility(View.GONE);
    }
}
