package com.milkywave.app;

import android.os.Bundle;
import android.text.TextUtils;       // Utilidades para comprobar strings vacíos
import android.util.Patterns;       // Patrón oficial para validar emails
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;       // Botón de registrar
import android.widget.EditText;     // Campos de texto del formulario
import android.widget.TextView;     // Texto clickable para volver al login
import android.widget.Toast;        // Mensajes rápidos al usuario

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;                         // Firebase Auth: crear usuario
import com.google.firebase.auth.FirebaseAuthUserCollisionException;   // Error específico: email ya registrado
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;    // Error específico: contraseña débil
import com.google.firebase.auth.FirebaseUser;                         // Usuario Firebase: uid, enviar verificación
import com.google.firebase.firestore.FieldValue;                      // serverTimestamp para createdAt
import com.google.firebase.firestore.FirebaseFirestore;               // Firestore: guardar perfil

import java.util.HashMap;
import java.util.Locale;     // Para normalizar email a minúsculas
import java.util.Map;

public class RegistroFragment extends Fragment {

    // Campos del formulario
    private EditText editNombre, editApellido1, editApellido2, editEmail, editContrasena;

    // Botón para registrar el usuario
    private Button btnRegistrar;

    // Texto para volver al login
    private TextView textVolverLogin;

    // Firebase Auth (crear usuario) y Firestore (guardar perfil)
    private FirebaseAuth auth;
    private FirebaseFirestore db;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflamos el layout del registro (registro.xml)
        View view = inflater.inflate(R.layout.registro, container, false);

        // --- Firebase ---
        // auth: gestiona creación de usuarios
        // db: permite guardar el perfil en Firestore
        auth = FirebaseAuth.getInstance();
        db   = FirebaseFirestore.getInstance();

        // --- Enlazar vistas (IDs del XML) ---
        editNombre      = view.findViewById(R.id.editTextNombreRegistro);
        editApellido1   = view.findViewById(R.id.editTextApellido1);
        editApellido2   = view.findViewById(R.id.editTextApellido2);
        editEmail       = view.findViewById(R.id.emailRegistro);
        editContrasena  = view.findViewById(R.id.contrasenaRegistro);
        btnRegistrar    = view.findViewById(R.id.btnRegistrar);
        textVolverLogin = view.findViewById(R.id.textVolverLogin);

        // Click en "Registrarse" -> ejecuta validaciones + crea usuario + guarda perfil
        btnRegistrar.setOnClickListener(v -> registrar());

        // Click en "¿Ya tienes cuenta?" -> vuelve al login siempre
        textVolverLogin.setOnClickListener(v -> volverALogin());

        return view;
    }

    /**
     * Registro completo:
     * 1) Limpia errores anteriores
     * 2) Lee los datos del formulario
     * 3) Valida campos obligatorios y formato
     * 4) Crea el usuario en FirebaseAuth
     * 5) Envía email de verificación
     * 6) Crea documento en Firestore con el perfil inicial (puntos = 0, createdAt)
     * 7) Limpia campos y vuelve al login
     */
    private void registrar() {
        // Quita mensajes de error previos en los EditText
        clearErrors();

        // Leemos campos con trim para evitar espacios accidentales
        String nombre     = safeText(editNombre);
        String apellido1  = safeText(editApellido1);
        String apellido2  = safeText(editApellido2);

        String emailRaw   = safeText(editEmail);
        String email      = emailRaw.toLowerCase(Locale.ROOT); // normaliza a minúsculas

        // Contraseña: se obtiene directamente del EditText
        String contrasena = editContrasena.getText() == null ? "" : editContrasena.getText().toString();

        // --- Validaciones básicas (campos obligatorios) ---
        if (TextUtils.isEmpty(nombre)) {
            editNombre.setError("Obligatorio");
            editNombre.requestFocus();
            toast("Completa los campos obligatorios (*)");
            return;
        }

        if (TextUtils.isEmpty(apellido1)) {
            editApellido1.setError("Obligatorio");
            editApellido1.requestFocus();
            toast("Completa los campos obligatorios (*)");
            return;
        }

        if (TextUtils.isEmpty(email)) {
            editEmail.setError("Obligatorio");
            editEmail.requestFocus();
            toast("Completa los campos obligatorios (*)");
            return;
        }

        // Validación del formato del email con patrón estándar de Android
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            editEmail.setError("Email no válido");
            editEmail.requestFocus();
            toast("Email no válido");
            return;
        }

        if (TextUtils.isEmpty(contrasena)) {
            editContrasena.setError("Obligatorio");
            editContrasena.requestFocus();
            toast("Completa los campos obligatorios (*)");
            return;
        }

        // Firebase exige mínimo 6 caracteres en contraseñas para email/password
        if (contrasena.trim().length() < 6) {
            editContrasena.setError("Mínimo 6 caracteres");
            editContrasena.requestFocus();
            toast("La contraseña debe tener al menos 6 caracteres");
            return;
        }

        // Validación custom: no permitir "ñ" en contraseña
        // (Probablemente para evitar problemas de encoding o para simplificar reglas)
        if (contrasena.trim().contains("ñ")) {
            editContrasena.setError("No puede llevar Ñ");
            editContrasena.requestFocus();
            toast("La contraseña no puede llevar Ñ");
            return;
        }

        // Evita doble click mientras se registra
        btnRegistrar.setEnabled(false);

        // --- Crear usuario en FirebaseAuth ---
        auth.createUserWithEmailAndPassword(email, contrasena)
                .addOnSuccessListener(result -> {

                    // Usuario recién creado (puede venir null en casos raros)
                    FirebaseUser user = result.getUser();

                    // UID es el identificador único del usuario en Firebase Auth
                    String uid = user != null ? user.getUid() : null;

                    // Si no tenemos UID, no podemos crear el perfil en Firestore
                    if (uid == null) {
                        resetUI();
                        toast("No se pudo obtener el UID del usuario");
                        return;
                    }

                    // Enviar email de verificación
                    // Esto manda el correo con el link para marcar el email como verificado.
                    if (user != null) {
                        user.sendEmailVerification();
                    }

                    // --- Crear perfil en Firestore ---
                    // Se guarda en colección "usuarios" con docId = uid
                    Map<String, Object> perfil = new HashMap<>();
                    perfil.put("nombre", nombre);
                    perfil.put("apellido1", apellido1);
                    perfil.put("apellido2", apellido2);
                    perfil.put("email", email);
                    perfil.put("puntos", 0); // puntos iniciales
                    perfil.put("createdAt", FieldValue.serverTimestamp()); // timestamp del servidor

                    db.collection("usuarios")
                            .document(uid)
                            .set(perfil)
                            .addOnSuccessListener(unused -> {
                                // Re-habilita UI
                                resetUI();

                                // Mensaje de éxito
                                toast("Registrado. Revisa tu correo para verificar la cuenta.");

                                // Limpiar campos
                                limpiarCampos();

                                // Volver al login
                                volverALogin();
                            })
                            .addOnFailureListener(e -> {
                                // Si falla Firestore, el usuario en Auth ya existe, pero no se guardó el perfil
                                resetUI();
                                toast("Error al guardar perfil: " + e.getMessage());
                            });
                })
                .addOnFailureListener(e -> {
                    // Si falla el registro, re-habilitamos UI
                    resetUI();

                    // Errores típicos controlados:
                    // - email ya existe
                    // - contraseña débil
                    if (e instanceof FirebaseAuthUserCollisionException) {
                        editEmail.setError("Este correo ya está registrado");
                        editEmail.requestFocus();
                        toast("Este correo ya está registrado. Prueba iniciar sesión.");
                    } else if (e instanceof FirebaseAuthWeakPasswordException) {
                        editContrasena.setError("Contraseña demasiado débil");
                        editContrasena.requestFocus();
                        toast("Contraseña demasiado débil. Prueba con otra.");
                    } else {
                        // Cualquier otro error (red, config, etc.)
                        toast("Error al registrar: " + e.getMessage());
                    }
                });
    }

    /**
     * Vuelve al login:
     * - Si el FragmentManager tiene backstack, hace popBackStack()
     * - Si no, reemplaza el fragment actual por LoginFragment
     *
     * Esto asegura que "volver" funcione siempre, incluso si no se usó backstack.
     */
    private void volverALogin() {
        if (getActivity() == null) return;

        // Si hay backstack, volvemos al fragment anterior
        if (getActivity().getSupportFragmentManager().getBackStackEntryCount() > 0) {
            getActivity().getSupportFragmentManager().popBackStack();
        } else {
            // Si no hay backstack, reemplazamos manualmente por LoginFragment
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).cambiarFragment(new LoginFragment());
            } else {
                getActivity().getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, new LoginFragment())
                        .commit();
            }
        }
    }

    /**
     * Limpia el contenido de todos los campos del formulario
     * y borra errores visuales.
     */
    private void limpiarCampos() {
        editNombre.setText("");
        editApellido1.setText("");
        editApellido2.setText("");
        editEmail.setText("");
        editContrasena.setText("");
        clearErrors();
    }

    /**
     * Devuelve la UI a su estado normal tras terminar el registro (ok o error).
     * En este caso solo re-habilita el botón.
     */
    private void resetUI() {
        btnRegistrar.setEnabled(true);
    }

    /**
     * Helper para mostrar Toasts.
     */
    private void toast(String msg) {
        Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show();
    }

    /**
     * Limpia los setError de todos los EditText.
     */
    private void clearErrors() {
        editNombre.setError(null);
        editApellido1.setError(null);
        editApellido2.setError(null);
        editEmail.setError(null);
        editContrasena.setError(null);
    }

    /**
     * Helper para leer texto de un EditText:
     * - si getText() es null -> ""
     * - si no -> texto con trim() (quita espacios al inicio/fin)
     */
    private String safeText(EditText et) {
        return et.getText() == null ? "" : et.getText().toString().trim();
    }
}
