package com.milkywave.app;

import android.app.Dialog;              // Tipo de objeto que devuelve un DialogFragment (el propio diálogo)
import android.os.Bundle;               // Para pasar/recuperar datos (arguments) al fragment
import android.view.LayoutInflater;     // Para inflar layouts XML dentro del diálogo
import android.view.View;               // Vista raíz del layout del diálogo y de cada item
import android.widget.ImageView;        // Para mostrar la imagen del producto y la de cada opción
import android.widget.LinearLayout;     // Contenedor donde se añaden dinámicamente las opciones
import android.widget.TextView;         // Para mostrar título, descripción, precio, etc.

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog; // Diálogo estilo Material/AppCompat
import androidx.fragment.app.DialogFragment; // Fragment especializado para mostrar un diálogo

public class ProductoDialogFragment extends DialogFragment {

    // Clave para guardar/leer el producto dentro del Bundle de argumentos
    private static final String ARG_PRODUCTO = "arg_producto";

    /**
     * Factory method (patrón recomendado) para crear el DialogFragment con un Producto dentro.
     * Así evitamos constructores con parámetros (no recomendado en Fragments).
     *
     * @param producto Producto a mostrar en el diálogo
     * @return instancia del diálogo ya configurada con arguments
     */
    public static ProductoDialogFragment newInstance(Producto producto) {
        ProductoDialogFragment f = new ProductoDialogFragment();

        // Bundle = "paquete" de datos que se asocia al fragment.
        // putSerializable: Producto implementa Serializable, por eso se puede guardar aquí.
        Bundle b = new Bundle();
        b.putSerializable(ARG_PRODUCTO, producto);

        // Guardamos el bundle como argumentos del fragment
        f.setArguments(b);
        return f;
    }

    /**
     * Se llama cuando el DialogFragment necesita crear el diálogo.
     * Aquí:
     * 1) Recuperamos el Producto de los arguments
     * 2) Inflamos el layout del diálogo
     * 3) Rellenamos los campos (título, desc, imagen)
     * 4) Pintamos dinámicamente las opciones dentro del contenedor
     * 5) Devolvemos un AlertDialog con botón "Cerrar"
     */
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {

        // Producto que queremos mostrar
        Producto producto = null;

        // Recuperamos argumentos si existen
        if (getArguments() != null) {
            // getSerializable devuelve Object, por eso hacemos comprobación de tipo
            Object o = getArguments().getSerializable(ARG_PRODUCTO);
            if (o instanceof Producto) producto = (Producto) o;
        }

        // Inflamos el layout del diálogo (dialog_producto.xml)
        View dialogView = LayoutInflater.from(requireContext())
                .inflate(R.layout.dialog_producto, null, false);

        // Referencias a vistas del diálogo
        TextView txtTitulo = dialogView.findViewById(R.id.txtTituloProducto);
        TextView txtDesc = dialogView.findViewById(R.id.txtDescripcionProducto);
        ImageView imgPrincipal = dialogView.findViewById(R.id.imgProductoPrincipal);

        // Contenedor donde se añadirán las opciones (views) dinámicamente
        LinearLayout container = dialogView.findViewById(R.id.containerOpciones);

        // Si el producto no es null, rellenamos todo
        if (producto != null) {

            // Título, descripción e imagen principal del producto
            txtTitulo.setText(producto.nombre);
            txtDesc.setText(producto.descripcion);
            imgPrincipal.setImageResource(producto.imagenPrincipalResId);

            // --- Pintar opciones ---

            // Por seguridad, vaciamos el contenedor (por si el diálogo se reusa/recrea)
            container.removeAllViews();

            // LayoutInflater para inflar cada "item" de opción
            LayoutInflater li = LayoutInflater.from(requireContext());

            // Recorremos todas las opciones del producto
            for (OpcionProducto op : producto.opciones) {

                // Inflamos un layout de opción (item_opcion_producto.xml)
                // container, false -> no lo añade automáticamente, lo añadimos nosotros al final
                View item = li.inflate(R.layout.item_opcion_producto, container, false);

                // Referencias a las vistas dentro de cada item
                ImageView img = item.findViewById(R.id.imgOpcion);
                TextView tTitulo = item.findViewById(R.id.txtTituloOpcion);
                TextView tDetalle = item.findViewById(R.id.txtDetalleOpcion);
                TextView tPrecio = item.findViewById(R.id.txtPrecioOpcion);

                // Rellenamos los datos de la opción
                img.setImageResource(op.imageResId);
                tTitulo.setText(op.titulo);
                tPrecio.setText(op.precio);

                // Si detalle está vacío o null, ocultamos el TextView para no dejar hueco
                if (op.detalle == null || op.detalle.trim().isEmpty()) {
                    tDetalle.setVisibility(View.GONE);
                } else {
                    // Si hay detalle, lo mostramos
                    tDetalle.setVisibility(View.VISIBLE);
                    tDetalle.setText(op.detalle);
                }

                // Finalmente añadimos el item al contenedor de opciones
                container.addView(item);
            }
        }

        // Creamos y devolvemos el diálogo.
        // - setView(dialogView) -> usa nuestro layout personalizado
        // - setPositiveButton("Cerrar", null) -> botón que simplemente cierra el diálogo
        return new AlertDialog.Builder(requireContext())
                .setView(dialogView)
                .setPositiveButton("Cerrar", null)
                .create();
    }
}
