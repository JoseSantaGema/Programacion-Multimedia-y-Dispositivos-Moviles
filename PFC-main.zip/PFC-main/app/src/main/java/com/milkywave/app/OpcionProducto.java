package com.milkywave.app;

import java.io.Serializable; // Permite convertir este objeto a un formato “transportable”

public class OpcionProducto implements Serializable {

    // Título de la opción (por ejemplo: "Pequeño", "Mediano", "Grande", "Con helado", etc.)
    // Se marca como final para que, una vez creado el objeto, no se pueda cambiar.
    public final String titulo;

    // Precio en formato texto (por ejemplo: "3,50 €")
    // Está como String para poder mostrarlo directamente sin formateos extra.
    public final String precio;

    // ID del recurso drawable que se va a mostrar como imagen
    // Es int porque los recursos en Android se referencian por un entero.
    public final int imageResId;

    // Texto extra opcional para dar más info
    public final String detalle;

    /**
     * Constructor:
     * Recibe todos los datos de la opción y los guarda en el objeto.
     *
     * @param titulo    Nombre de la opción (tamaño/sabor/variante)
     * @param precio    Precio en texto para mostrarlo tal cual en UI
     * @param imageResId Recurso drawable asociado a esta opción
     * @param detalle   Descripción corta opcional (puede ser "" si no quieres mostrar nada)
     */
    public OpcionProducto(String titulo, String precio, int imageResId, String detalle) {
        this.titulo = titulo;
        this.precio = precio;
        this.imageResId = imageResId;
        this.detalle = detalle;
    }
}
