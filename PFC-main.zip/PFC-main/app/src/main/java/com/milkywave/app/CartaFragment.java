package com.milkywave.app;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

public class CartaFragment extends Fragment {

    // Constructor vacío obligatorio para que Android pueda recrear el Fragment si lo necesita
    public CartaFragment() {}

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        // Inflamos el layout XML de este Fragment (fragment_carta.xml)
        View view = inflater.inflate(R.layout.fragment_carta, container, false);

        // ------------------------------
        // 1) Construimos los productos
        // ------------------------------
        // Cada "Producto" representa una categoría de la carta (Original, Tarrina, etc.)
        // y dentro lleva una lista de opciones (tamaños / sabores / variantes) con su precio e imagen.
        Producto original = buildOriginal();
        Producto tarrina = buildTarrina();
        Producto combo = buildCombo();
        Producto milkshake = buildMilkshake();
        Producto gofreBelga = buildGofreBelga();
        Producto gofreBubble = buildGofreBubble();

        // ------------------------------
        // 2) Asignamos los clicks a cada tarjeta del layout
        // ------------------------------
        // Al pulsar en una "card_*" se abre un diálogo (ProductoDialogFragment)
        // mostrando la info del producto y sus opciones.
        view.findViewById(R.id.card_original).setOnClickListener(v -> mostrarProducto(original));
        view.findViewById(R.id.card_tarrina).setOnClickListener(v -> mostrarProducto(tarrina));
        view.findViewById(R.id.card_combo).setOnClickListener(v -> mostrarProducto(combo));
        view.findViewById(R.id.card_milkshake).setOnClickListener(v -> mostrarProducto(milkshake));
        view.findViewById(R.id.card_gofre_belga).setOnClickListener(v -> mostrarProducto(gofreBelga));
        view.findViewById(R.id.card_gofre_bubble).setOnClickListener(v -> mostrarProducto(gofreBubble));

        // Devolvemos la vista para que el Fragment se muestre
        return view;
    }

    /**
     * Abre un diálogo (DialogFragment) con la información del producto.
     * Se usa getParentFragmentManager() para que el dialog se gestione con el fragment manager actual.
     *
     * "producto_dialog" es solo una etiqueta (tag) útil por si quieres buscar el diálogo luego.
     */
    private void mostrarProducto(Producto producto) {
        ProductoDialogFragment.newInstance(producto)
                .show(getParentFragmentManager(), "producto_dialog");
    }

    // -------------------------------------------------
    // Construcción de productos (datos "hardcodeados")
    // -------------------------------------------------
    // Cada buildX() crea:
    //  - ArrayList<OpcionProducto> con opciones (tamaño/sabor + precio + imagen + mini descripción)
    //  - String desc con la descripción general del producto
    //  - Un Producto final con nombre + descripción + imagen principal + opciones

    /**
     * Producto: "Original"
     * Opciones: Pequeño/Mediano/Grande (mismos sabores pero distinto tamaño/precio)
     */
    private Producto buildOriginal() {
        ArrayList<OpcionProducto> ops = new ArrayList<>();

        // Cada OpcionProducto parece llevar:
        // (nombreOpcion, precio, drawable, fraseCorta)
        ops.add(new OpcionProducto("Pequeño", "3,50 €", R.drawable.original, "Ideal para un antojo rápido"));
        ops.add(new OpcionProducto("Mediano", "4,30 €", R.drawable.original, "El tamaño perfecto para disfrutar"));
        ops.add(new OpcionProducto("Grande", "5,10 €", R.drawable.original, "Para los más golosos"));

        // Descripción general que se verá en el diálogo
        String desc = "Nuestro Original puede ser de vainilla, chocolate o mixto. ";

        // Producto(nombre, descripcion, imagenPrincipal, listaOpciones)
        return new Producto("Original", desc, R.drawable.original, ops);
    }

    /**
     * Producto: "Tarrina"
     * Opciones: Pequeña/Mediana/Grande (cambian toppings incluidos)
     */
    private Producto buildTarrina() {
        ArrayList<OpcionProducto> ops = new ArrayList<>();
        ops.add(new OpcionProducto("Pequeña", "3,50 €", R.drawable.tarrina, "Incluye 1 topping"));
        ops.add(new OpcionProducto("Mediana", "4,30 €", R.drawable.tarrina, "Incluye 2 toppings"));
        ops.add(new OpcionProducto("Grande", "5,10 €", R.drawable.tarrina, "Incluye 3 toppings"));

        // Aquí se concatenan frases como descripción, hay que tener cuidado de que los espacios estén bien
        String desc = "Tarrina cremosa con toppings a tu elección. " +
                "Combinala con tus toppings favoritos." +
                "Puedes añadirle toppings extra por 60 céntimos cada uno.";

        return new Producto("Tarrina", desc, R.drawable.tarrina, ops);
    }

    /**
     * Producto: "Combo"
     * Opciones: sabores/recetas ya definidas (Crunch Berry, Lotus Passion, Personalizado)
     */
    private Producto buildCombo() {
        ArrayList<OpcionProducto> ops = new ArrayList<>();

        // combo2 es la imagen con los 3 juntos.
        // Aquí cada opción usa R.drawable.combo2 como imagen de opción.
        ops.add(new OpcionProducto("Crunch Berry", "5,10 €", R.drawable.combo2, "Crujiente + dulce (top ventas)"));
        ops.add(new OpcionProducto("Lotus Passion", "5,10 €", R.drawable.combo2, "Sabor Lotus con toque caramelizado"));
        ops.add(new OpcionProducto("Personalizado", "5,10 €", R.drawable.combo2, "Elige base y toppings a tu gusto"));

        String desc = "Nuestros combos son recetas especiales listas para disfrutar. " +
                "También puedes personalizarlo como quieras." +
                "Puedes añadirle toppings extra por 60 céntimos cada uno.";

        return new Producto("Combo", desc, R.drawable.combo, ops);
    }

    /**
     * Producto: "Milkshake"
     * Opciones: sabores (vainilla/chocolate/fresa)
     * Imagen principal: vainilla
     */
    private Producto buildMilkshake() {
        ArrayList<OpcionProducto> ops = new ArrayList<>();
        ops.add(new OpcionProducto("Vainilla", "4,30 €", R.drawable.milkshake_vainilla, "Suave y clásico"));
        ops.add(new OpcionProducto("Chocolate", "4,30 €", R.drawable.milkshake_chocolate, "Intenso y cremoso"));
        ops.add(new OpcionProducto("Fresa", "4,30 €", R.drawable.milkshake_fresa, "Fresco y afrutado"));

        String desc = "Batido cremoso y bien frío. Ideal para llevar o tomar en tienda. " +
                "Puedes añadirle toppings extra por 60 céntimos cada uno.";

        // Imagen principal: vainilla (la que se muestra como portada del producto)
        return new Producto("Milkshake", desc, R.drawable.milkshake_vainilla, ops);
    }

    /**
     * Producto: "Gofre Belga"
     * Opciones: con/sin helado
     */
    private Producto buildGofreBelga() {
        ArrayList<OpcionProducto> ops = new ArrayList<>();
        ops.add(new OpcionProducto("Sin helado", "3,50 €", R.drawable.gofre_belga, "Incluye 1 topping"));
        ops.add(new OpcionProducto("Con helado", "4,30 €", R.drawable.gofre_belga, "Incluye 1 topping"));

        String desc = "Gofre belga crujiente por fuera y suave por dentro. " +
                "Añade helado si quieres un extra irresistible. " +
                "Puedes añadirle toppings extra por 60 céntimos cada uno.";

        return new Producto("Gofre Belga", desc, R.drawable.gofre_belga, ops);
    }

    /**
     * Producto: "Gofre Bubble"
     * Opciones: con/sin helado
     */
    private Producto buildGofreBubble() {
        ArrayList<OpcionProducto> ops = new ArrayList<>();
        ops.add(new OpcionProducto("Sin helado", "4,30 €", R.drawable.gofre_bubble, "Incluye 1 topping"));
        ops.add(new OpcionProducto("Con helado", "5,10 €", R.drawable.gofre_bubble, "Incluye 1 topping"));

        String desc = "Gofre bubble con burbujas, perfecto para rellenar con helado y toppings. " +
                "Puedes añadirle toppings extra por 60 céntimos cada uno.";

        return new Producto("Gofre Bubble", desc, R.drawable.gofre_bubble, ops);
    }
}
