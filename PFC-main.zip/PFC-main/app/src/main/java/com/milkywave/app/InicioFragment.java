package com.milkywave.app;

import android.app.AlertDialog; // Diálogos para avisos (QR incorrecto, verificación requerida, etc.)
import android.content.Intent;  // Para abrir enlaces y lanzar el escáner mediante intents internos
import android.net.Uri;         // Para parsear el contenido del QR si viene como URL con parámetros
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;      // Referencias a botones del layout
import android.widget.LinearLayout; // Referencia al banner (contenedor)
import android.widget.TextView;    // Texto donde se muestra estado de puntos / verificación

import androidx.activity.result.ActivityResultLauncher; // API moderna para recibir resultados (escáner)
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;         // Auth: usuario actual, verificación, etc.
import com.google.firebase.auth.FirebaseUser;         // Usuario Firebase (reload, isEmailVerified, etc.)
import com.google.firebase.firestore.FieldValue;      // serverTimestamp e increment
import com.google.firebase.firestore.FirebaseFirestore; // Firestore: tickets y usuarios
import com.journeyapps.barcodescanner.ScanContract;   // Contrato del escáner (JourneyApps / ZXing)
import com.journeyapps.barcodescanner.ScanOptions;    // Opciones de escaneo (QR only, beep, etc.)

import java.util.HashMap;
import java.util.Map;

public class InicioFragment extends Fragment {

    // NIF de la empresa: sirve para validar que el ticket pertenece a "tu" negocio
    // (si el QR no trae este NIF, se considera inválido)
    private static final String NIF_EMPRESA = "B44892941";

    // Firestore para leer/escribir usuarios y tickets
    private FirebaseFirestore db;

    // FirebaseAuth para saber quién está logueado y comprobar verificación email
    private FirebaseAuth auth;

    // Launcher del escáner QR (API moderna Activity Result)
    // Al terminar el escaneo, llega el resultado al callback registrado en onCreate()
    private ActivityResultLauncher<ScanOptions> qrLauncher;

    // ----- UI -----
    // Banner rojo que aparece si el usuario NO ha verificado el email
    private LinearLayout bannerVerificacion;

    // Botones del banner: reenviar email verificación / recargar estado (tras verificar)
    private Button btnReenviarVerificacion, btnRecargarVerificacion;

    // Texto que muestra: "Puntos: X" o mensajes de verificación
    private TextView txtEstadoPuntos;

    // Botón para escanear puntos (se desactiva si no hay verificación)
    private Button btnEscanear;

    // Flag local para saber si la cuenta está verificada y controlar la UI/flujo
    private boolean cuentaVerificada = false;

    public InicioFragment() {}

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Registramos el launcher del escáner UNA vez.
        // registerForActivityResult asocia un callback que se ejecuta cuando vuelve el resultado.
        qrLauncher = registerForActivityResult(
                new ScanContract(),
                result -> {
                    // Si result es null (caso raro), avisamos
                    if (result == null) {
                        mostrarAviso("Aviso", "No se pudo leer el QR");
                        return;
                    }

                    // getContents() trae el texto del QR escaneado
                    String contenido = result.getContents();

                    // Si está vacío, lo tratamos como QR incorrecto
                    if (contenido == null || contenido.trim().isEmpty()) {
                        mostrarQrEquivocado();
                        return;
                    }

                    // Si hay contenido, lo procesamos (validaciones + sumar puntos)
                    procesarQR(contenido.trim());
                }
        );
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        // Inflamos el layout del Inicio (fragment_inicio.xml)
        View view = inflater.inflate(R.layout.fragment_inicio, container, false);

        // Inicializamos Firebase
        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();

        // Referencias a la UI
        bannerVerificacion = view.findViewById(R.id.banner_verificacion);
        btnReenviarVerificacion = view.findViewById(R.id.btn_reenviar_verificacion);
        btnRecargarVerificacion = view.findViewById(R.id.btn_recargar_verificacion);
        txtEstadoPuntos = view.findViewById(R.id.txt_estado_puntos);
        btnEscanear = view.findViewById(R.id.btn_escanear_puntos);

        // Botón "Escanear puntos":
        // - Si no está verificada la cuenta, bloqueamos y avisamos
        // - Si está verificada, abrimos el escáner
        btnEscanear.setOnClickListener(v -> {
            if (!cuentaVerificada) {
                mostrarAviso("Verificación requerida", "Verifica la cuenta antes de usar esta función.");
                return;
            }
            escanearQR();
        });

        // Botón "Reenviar email": manda otra vez el email de verificación
        btnReenviarVerificacion.setOnClickListener(v -> reenviarVerificacion());

        // Botón "Ya verifiqué": recarga el estado de verificación desde Firebase
        btnRecargarVerificacion.setOnClickListener(v -> recargarEstadoVerificacion());

        // Configura listeners de redes sociales (instagram, facebook, linkedin)
        configurarRedes(view);

        // Estado inicial al entrar:
        // recargamos la verificación (reload del user) y actualizamos UI
        recargarEstadoVerificacion();

        return view;
    }

    /**
     * Refresca el estado real de verificación de email:
     * - FirebaseUser.isEmailVerified() solo se actualiza bien después de user.reload()
     * - Si está verificada, carga puntos desde Firestore.
     */
    private void recargarEstadoVerificacion() {
        FirebaseUser user = auth.getCurrentUser();

        // Si no hay usuario logueado, marcamos como no verificado y ajustamos la UI
        if (user == null) {
            cuentaVerificada = false;
            aplicarUIVerificacion(false);
            return;
        }

        // reload() fuerza a Firebase a refrescar el estado del usuario (incluye emailVerified)
        user.reload()
                .addOnSuccessListener(unused -> {
                    // Actualizamos la flag local
                    cuentaVerificada = user.isEmailVerified();

                    // Aplicamos UI según verificación
                    aplicarUIVerificacion(cuentaVerificada);

                    // Si ya está verificada, cargamos puntos reales
                    if (cuentaVerificada) cargarPuntos();
                })
                .addOnFailureListener(e -> {
                    // Si falla reload (red, etc.), por seguridad bloqueamos funciones
                    cuentaVerificada = false;
                    aplicarUIVerificacion(false);
                });
    }

    /**
     * Cambia la interfaz según si el usuario está verificado o no:
     * - Verificado: ocultamos banner, habilitamos escaneo, mostramos "Puntos: ..."
     * - No verificado: mostramos banner, deshabilitamos escaneo, mostramos mensaje
     */
    private void aplicarUIVerificacion(boolean verificada) {
        if (verificada) {
            bannerVerificacion.setVisibility(View.GONE);
            btnEscanear.setEnabled(true);
            txtEstadoPuntos.setText("Puntos: ..."); // placeholder hasta que cargue Firestore
        } else {
            bannerVerificacion.setVisibility(View.VISIBLE);
            btnEscanear.setEnabled(false);
            txtEstadoPuntos.setText("Verifica la cuenta antes de usar esta función");
        }
    }

    /**
     * Reenvía el email de verificación oficial de Firebase.
     * Si funciona, muestra aviso al usuario.
     */
    private void reenviarVerificacion() {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) return;

        user.sendEmailVerification()
                .addOnSuccessListener(unused ->
                        mostrarAviso("Verificación enviada", "Revisa tu correo y pulsa el enlace para verificar tu cuenta.")
                )
                .addOnFailureListener(e ->
                        mostrarAviso("Error", "No se pudo enviar: " + e.getMessage())
                );
    }

    /**
     * Carga el campo "puntos" del usuario desde Firestore y lo muestra en pantalla.
     * - Si no existe, pone 0.
     */
    private void cargarPuntos() {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) return;

        db.collection("usuarios")
                .document(user.getUid())
                .get()
                .addOnSuccessListener(doc -> {
                    long puntos = 0;

                    // Si el documento existe y tiene el campo "puntos", lo intentamos leer
                    if (doc.exists() && doc.get("puntos") != null) {
                        Object p = doc.get("puntos");

                        // Controlamos que sea un número (Long/Double/etc.) para evitar ClassCastException
                        if (p instanceof Number) puntos = ((Number) p).longValue();
                    }

                    txtEstadoPuntos.setText("Puntos: " + puntos);
                })
                .addOnFailureListener(e -> txtEstadoPuntos.setText("Puntos: 0"));
    }

    /**
     * Lanza la cámara/escáner QR.
     * Tiene doble check:
     * - que haya usuario logueado
     * - que esté verificado
     */
    private void escanearQR() {
        if (auth.getCurrentUser() == null) {
            mostrarAviso("Aviso", "Debes iniciar sesión para escanear puntos.");
            return;
        }
        if (!cuentaVerificada) {
            mostrarAviso("Verificación requerida", "Verifica la cuenta antes de usar esta función.");
            return;
        }

        // Configuración del escáner
        ScanOptions options = new ScanOptions();
        options.setPrompt("Escanea el QR de tu ticket");     // Texto en pantalla
        options.setBeepEnabled(true);                        // Sonido al escanear
        options.setOrientationLocked(true);                  // Bloquea orientación
        options.setDesiredBarcodeFormats(ScanOptions.QR_CODE); // Solo QR

        // Lanzamos el escáner; el resultado volverá al callback del qrLauncher
        qrLauncher.launch(options);
    }

    /**
     * Procesa el texto del QR:
     * - Verifica que la cuenta esté verificada
     * - Intenta extraer parámetros: nif, numserie, importe
     * - Valida que el NIF coincida con el de la empresa
     * - Calcula puntos = floor(importe * 10)
     * - Guarda ticket + incrementa puntos
     */
    private void procesarQR(String qrText) {
        // Seguridad: si no está verificado, no permitimos sumar puntos
        if (!cuentaVerificada) {
            mostrarAviso("Verificación requerida", "Verifica la cuenta antes de usar esta función.");
            return;
        }

        try {
            String raw = qrText.trim();

            // Intentamos parsear como URI porque el QR es tipo:
            // https://...?...&nif=...&numserie=...&importe=...
            Uri uri = Uri.parse(raw);

            // Extraemos parámetros vía queryParameter (si es una URL "bien formada")
            String nif = uri.getQueryParameter("nif");
            String idFactura = uri.getQueryParameter("numserie");
            String importeStr = uri.getQueryParameter("importe");

            // Fallback: si no vinieron como query, intentamos extraer "a mano"
            if (nif == null || nif.isEmpty()) nif = extraerParametro(raw, "nif");
            if (idFactura == null || idFactura.isEmpty()) idFactura = extraerParametro(raw, "numserie");
            if (importeStr == null || importeStr.isEmpty()) importeStr = extraerParametro(raw, "importe");

            // Si falta algún parámetro, QR inválido
            if (nif == null || nif.isEmpty()
                    || idFactura == null || idFactura.isEmpty()
                    || importeStr == null || importeStr.isEmpty()) {
                mostrarQrEquivocado();
                return;
            }

            // Validamos que el ticket sea de nuestra empresa
            if (!NIF_EMPRESA.equalsIgnoreCase(nif.trim())) {
                mostrarQrEquivocado();
                return;
            }

            // Normalizamos decimales: "3,50" -> "3.50"
            importeStr = importeStr.trim().replace(",", ".");

            // Convertimos a número
            double importe = Double.parseDouble(importeStr);

            // Regla: 10 puntos por 1€ (floor para evitar decimales)
            int puntos = (int) Math.floor(importe * 10);

            // Guardamos ticket + sumamos puntos al usuario
            crearTicketYSumarPuntos(idFactura, importe, puntos);

        } catch (Exception e) {
            // Si algo falla (parse, formato, etc.), lo tratamos como QR incorrecto
            mostrarQrEquivocado();
        }
    }

    /**
     * Guarda un ticket en la colección "tickets" con ID = numserie (idFactura)
     * y si se guarda correctamente:
     * - incrementa los puntos del usuario en "usuarios/{uid}" con FieldValue.increment(...)
     */
    private void crearTicketYSumarPuntos(String idFactura, double importe, int puntos) {
        // UID del usuario logueado (aquí se asume que no es null porque vienes de escaneo validado)
        String uid = auth.getCurrentUser().getUid();

        // Mapa con datos del ticket a guardar
        Map<String, Object> ticket = new HashMap<>();
        ticket.put("uid", uid);                         // quién lo escaneó
        ticket.put("importe", importe);                 // importe del ticket
        ticket.put("puntos", puntos);                   // puntos calculados
        ticket.put("fecha", FieldValue.serverTimestamp()); // fecha del servidor (más fiable que el móvil)

        // 1) Guardamos el ticket con docId = idFactura (numserie)
        db.collection("tickets")
                .document(idFactura)
                .set(ticket)
                .addOnSuccessListener(unused -> {
                    // 2) Si el ticket se guardó, incrementamos puntos del usuario
                    db.collection("usuarios")
                            .document(uid)
                            .update("puntos", FieldValue.increment(puntos))
                            .addOnSuccessListener(u2 -> {
                                // Aviso de éxito y refresco del contador
                                mostrarAviso("¡Enhorabuena! 🎉", "Has ganado " + puntos + " puntos");
                                cargarPuntos();
                            })
                            .addOnFailureListener(e ->
                                    // Si falla el update, el ticket sí se guardó pero los puntos no subieron, (arreglar después)
                                    mostrarAviso("Aviso", "Ticket guardado, pero no se pudieron actualizar los puntos.")
                            );
                })
                .addOnFailureListener(e ->
                        // Si falla, aquí se interpreta como ticket ya usado
                        mostrarAviso("Ticket ya utilizado", "Este ticket ya ha sido escaneado anteriormente.")
                );
    }

    /**
     * Extrae un parámetro tipo "clave=valor" de una cadena.
     * Se usa como fallback por si el QR no es una URL bien formada.
     *
     * Ejemplo: extraerParametro("...nif=B123&importe=3.5...", "importe") -> "3.5"
     */
    @Nullable
    private String extraerParametro(String text, String clave) {
        String patron = clave + "=";
        int i = text.indexOf(patron);
        if (i < 0) return null;

        int start = i + patron.length();
        int end = text.indexOf("&", start);
        if (end < 0) end = text.length();

        if (start <= end && end <= text.length()) {
            return text.substring(start, end);
        }
        return null;
    }

    /**
     * Aviso estándar cuando el QR no cumple:
     * - faltan parámetros
     * - nif distinto
     * - formato incorrecto
     */
    private void mostrarQrEquivocado() {
        mostrarAviso("QR equivocado", "El código escaneado no corresponde a un ticket válido.");
    }

    /**
     * Muestra un diálogo genérico con título y mensaje.
     * Lo reutilizas para casi todos los avisos del fragment.
     */
    private void mostrarAviso(String titulo, String msg) {
        new AlertDialog.Builder(requireContext())
                .setTitle(titulo)
                .setMessage(msg)
                .setPositiveButton("Aceptar", null)
                .show();
    }

    /**
     * Asigna listeners a los iconos de redes:
     * Cada click abre la URL correspondiente en el navegador.
     */
    private void configurarRedes(View view) {
        view.findViewById(R.id.icon_facebook)
                .setOnClickListener(v -> abrir("https://www.facebook.com/milkywaveoriginal"));

        view.findViewById(R.id.icon_instagram)
                .setOnClickListener(v -> abrir("https://www.instagram.com/milkywaveoriginal?igsh=bXhiMmF1aXI5Zjg0"));

        view.findViewById(R.id.icon_linkedin)
                .setOnClickListener(v -> abrir("https://www.linkedin.com/company/milkywaveoriginal"));
    }

    /**
     * Abre un enlace en el navegador mediante Intent implícito.
     */
    private void abrir(String url) {
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
    }
}
